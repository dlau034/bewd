# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
MoviesApp::Application.config.secret_key_base = '4c4f352cd1f14add68168fdc0e184a6eeebe9087083eee97400b214e889667f127590b050a48fd1eca5e82e9a9911eca0f914c49472047ac9bfe232ab1ae1a4c'
